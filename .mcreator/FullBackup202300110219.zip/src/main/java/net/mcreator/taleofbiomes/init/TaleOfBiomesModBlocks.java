
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.taleofbiomes.block.WildIndigoFlowerPotBlock;
import net.mcreator.taleofbiomes.block.WildIndigoBlock;
import net.mcreator.taleofbiomes.block.TilledSoilBlock;
import net.mcreator.taleofbiomes.block.StoneBlock;
import net.mcreator.taleofbiomes.block.SandBlock;
import net.mcreator.taleofbiomes.block.PurpleAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.PurpleAsterBlock;
import net.mcreator.taleofbiomes.block.MagentaAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.MagentaAsterBlock;
import net.mcreator.taleofbiomes.block.GrassBlockBlock;
import net.mcreator.taleofbiomes.block.GoldenrodFlowerPotBlock;
import net.mcreator.taleofbiomes.block.GoldenrodBlock;
import net.mcreator.taleofbiomes.block.FertileSoilBlock;
import net.mcreator.taleofbiomes.block.DirtBlock;
import net.mcreator.taleofbiomes.block.BlueAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.BlueAsterBlock;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Block> STONE = REGISTRY.register("stone", () -> new StoneBlock());
	public static final RegistryObject<Block> SAND = REGISTRY.register("sand", () -> new SandBlock());
	public static final RegistryObject<Block> GRASS_BLOCK = REGISTRY.register("grass_block", () -> new GrassBlockBlock());
	public static final RegistryObject<Block> DIRT = REGISTRY.register("dirt", () -> new DirtBlock());
	public static final RegistryObject<Block> BLUE_ASTER = REGISTRY.register("blue_aster", () -> new BlueAsterBlock());
	public static final RegistryObject<Block> PURPLE_ASTER = REGISTRY.register("purple_aster", () -> new PurpleAsterBlock());
	public static final RegistryObject<Block> MAGENTA_ASTER = REGISTRY.register("magenta_aster", () -> new MagentaAsterBlock());
	public static final RegistryObject<Block> GOLDENROD = REGISTRY.register("goldenrod", () -> new GoldenrodBlock());
	public static final RegistryObject<Block> WILD_INDIGO = REGISTRY.register("wild_indigo", () -> new WildIndigoBlock());
	public static final RegistryObject<Block> BLUE_ASTER_FLOWER_POT = REGISTRY.register("blue_aster_flower_pot", () -> new BlueAsterFlowerPotBlock());
	public static final RegistryObject<Block> PURPLE_ASTER_FLOWER_POT = REGISTRY.register("purple_aster_flower_pot", () -> new PurpleAsterFlowerPotBlock());
	public static final RegistryObject<Block> MAGENTA_ASTER_FLOWER_POT = REGISTRY.register("magenta_aster_flower_pot", () -> new MagentaAsterFlowerPotBlock());
	public static final RegistryObject<Block> GOLDENROD_FLOWER_POT = REGISTRY.register("goldenrod_flower_pot", () -> new GoldenrodFlowerPotBlock());
	public static final RegistryObject<Block> WILD_INDIGO_FLOWER_POT = REGISTRY.register("wild_indigo_flower_pot", () -> new WildIndigoFlowerPotBlock());
	public static final RegistryObject<Block> FERTILE_SOIL = REGISTRY.register("fertile_soil", () -> new FertileSoilBlock());
	public static final RegistryObject<Block> TILLED_SOIL = REGISTRY.register("tilled_soil", () -> new TilledSoilBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			GrassBlockBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			GrassBlockBlock.itemColorLoad(event);
		}
	}
}
