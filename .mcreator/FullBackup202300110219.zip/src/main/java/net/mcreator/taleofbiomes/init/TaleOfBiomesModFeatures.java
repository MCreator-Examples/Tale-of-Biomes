
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.taleofbiomes.world.features.plants.WildIndigoFeature;
import net.mcreator.taleofbiomes.world.features.plants.PurpleAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.MagentaAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.GoldenrodFeature;
import net.mcreator.taleofbiomes.world.features.plants.BlueAsterFeature;
import net.mcreator.taleofbiomes.world.features.ores.SandFeature;
import net.mcreator.taleofbiomes.world.features.ores.FertileSoilFeature;
import net.mcreator.taleofbiomes.world.features.ores.DirtFeature;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

@Mod.EventBusSubscriber
public class TaleOfBiomesModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Feature<?>> SAND = REGISTRY.register("sand", SandFeature::feature);
	public static final RegistryObject<Feature<?>> DIRT = REGISTRY.register("dirt", DirtFeature::feature);
	public static final RegistryObject<Feature<?>> BLUE_ASTER = REGISTRY.register("blue_aster", BlueAsterFeature::feature);
	public static final RegistryObject<Feature<?>> PURPLE_ASTER = REGISTRY.register("purple_aster", PurpleAsterFeature::feature);
	public static final RegistryObject<Feature<?>> MAGENTA_ASTER = REGISTRY.register("magenta_aster", MagentaAsterFeature::feature);
	public static final RegistryObject<Feature<?>> GOLDENROD = REGISTRY.register("goldenrod", GoldenrodFeature::feature);
	public static final RegistryObject<Feature<?>> WILD_INDIGO = REGISTRY.register("wild_indigo", WildIndigoFeature::feature);
	public static final RegistryObject<Feature<?>> FERTILE_SOIL = REGISTRY.register("fertile_soil", FertileSoilFeature::feature);
}
