
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.taleofbiomes.world.features.plants.WildIndigoFeature;
import net.mcreator.taleofbiomes.world.features.plants.PurpleAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.MagentaAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.GoldenrodFeature;
import net.mcreator.taleofbiomes.world.features.plants.BlueAsterFeature;
import net.mcreator.taleofbiomes.world.features.ores.SandFeature;
import net.mcreator.taleofbiomes.world.features.ores.PureCoalOreFeature;
import net.mcreator.taleofbiomes.world.features.ores.GravelFeature;
import net.mcreator.taleofbiomes.world.features.ores.FertileSoilFeature;
import net.mcreator.taleofbiomes.world.features.ores.DirtFeature;
import net.mcreator.taleofbiomes.world.features.RoseShrubPlant2Feature;
import net.mcreator.taleofbiomes.world.features.RoseShrubPlant1Feature;
import net.mcreator.taleofbiomes.world.features.PhosphoriteCrystalSmallFeature;
import net.mcreator.taleofbiomes.world.features.PhosphoriteCrystalLaregeFeature;
import net.mcreator.taleofbiomes.world.features.IvyShrubPlant2Feature;
import net.mcreator.taleofbiomes.world.features.IvyShrubPlant1Feature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationTwoForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationThreeForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationOneForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

@Mod.EventBusSubscriber
public class TaleOfBiomesModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Feature<?>> SAND = REGISTRY.register("sand", SandFeature::feature);
	public static final RegistryObject<Feature<?>> DIRT = REGISTRY.register("dirt", DirtFeature::feature);
	public static final RegistryObject<Feature<?>> BLUE_ASTER = REGISTRY.register("blue_aster", BlueAsterFeature::feature);
	public static final RegistryObject<Feature<?>> PURPLE_ASTER = REGISTRY.register("purple_aster", PurpleAsterFeature::feature);
	public static final RegistryObject<Feature<?>> MAGENTA_ASTER = REGISTRY.register("magenta_aster", MagentaAsterFeature::feature);
	public static final RegistryObject<Feature<?>> GOLDENROD = REGISTRY.register("goldenrod", GoldenrodFeature::feature);
	public static final RegistryObject<Feature<?>> WILD_INDIGO = REGISTRY.register("wild_indigo", WildIndigoFeature::feature);
	public static final RegistryObject<Feature<?>> FERTILE_SOIL = REGISTRY.register("fertile_soil", FertileSoilFeature::feature);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_ONE_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_one_for_plains_biomes", GrassGenerationOneForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_TWO_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_two_for_plains_biomes", GrassGenerationTwoForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_THREE_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_three_for_plains_biomes", GrassGenerationThreeForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> IVY_SHRUB_PLANT_1 = REGISTRY.register("ivy_shrub_plant_1", IvyShrubPlant1Feature::feature);
	public static final RegistryObject<Feature<?>> IVY_SHRUB_PLANT_2 = REGISTRY.register("ivy_shrub_plant_2", IvyShrubPlant2Feature::feature);
	public static final RegistryObject<Feature<?>> ROSE_SHRUB_PLANT_1 = REGISTRY.register("rose_shrub_plant_1", RoseShrubPlant1Feature::feature);
	public static final RegistryObject<Feature<?>> ROSE_SHRUB_PLANT_2 = REGISTRY.register("rose_shrub_plant_2", RoseShrubPlant2Feature::feature);
	public static final RegistryObject<Feature<?>> PURE_COAL_ORE = REGISTRY.register("pure_coal_ore", PureCoalOreFeature::feature);
	public static final RegistryObject<Feature<?>> GRAVEL = REGISTRY.register("gravel", GravelFeature::feature);
	public static final RegistryObject<Feature<?>> PHOSPHORITE_CRYSTAL_LAREGE = REGISTRY.register("phosphorite_crystal_larege", PhosphoriteCrystalLaregeFeature::feature);
	public static final RegistryObject<Feature<?>> PHOSPHORITE_CRYSTAL_SMALL = REGISTRY.register("phosphorite_crystal_small", PhosphoriteCrystalSmallFeature::feature);
}
