package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.LevelAccessor;

public class SmallShrubPlantAdditionalGenerationConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (SmallShrubPlacementScriptProcedure.execute(world, x, y, z) == true) {
			return true;
		}
		return false;
	}
}
