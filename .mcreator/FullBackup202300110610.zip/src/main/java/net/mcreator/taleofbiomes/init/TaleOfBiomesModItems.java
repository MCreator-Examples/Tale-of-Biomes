
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.taleofbiomes.item.PhosphoriteSwordItem;
import net.mcreator.taleofbiomes.item.PhosphoriteShovelItem;
import net.mcreator.taleofbiomes.item.PhosphoritePickaxeItem;
import net.mcreator.taleofbiomes.item.PhosphoriteHoeItem;
import net.mcreator.taleofbiomes.item.PhosphoriteGemstoneItem;
import net.mcreator.taleofbiomes.item.PhosphoriteAxeItem;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Item> STONE = block(TaleOfBiomesModBlocks.STONE, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> SAND = block(TaleOfBiomesModBlocks.SAND, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> GRASS_BLOCK = block(TaleOfBiomesModBlocks.GRASS_BLOCK, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> DIRT = block(TaleOfBiomesModBlocks.DIRT, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> BLUE_ASTER = block(TaleOfBiomesModBlocks.BLUE_ASTER, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PURPLE_ASTER = block(TaleOfBiomesModBlocks.PURPLE_ASTER, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> MAGENTA_ASTER = block(TaleOfBiomesModBlocks.MAGENTA_ASTER, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> GOLDENROD = block(TaleOfBiomesModBlocks.GOLDENROD, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> WILD_INDIGO = block(TaleOfBiomesModBlocks.WILD_INDIGO, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> BLUE_ASTER_FLOWER_POT = block(TaleOfBiomesModBlocks.BLUE_ASTER_FLOWER_POT, null);
	public static final RegistryObject<Item> PURPLE_ASTER_FLOWER_POT = block(TaleOfBiomesModBlocks.PURPLE_ASTER_FLOWER_POT, null);
	public static final RegistryObject<Item> MAGENTA_ASTER_FLOWER_POT = block(TaleOfBiomesModBlocks.MAGENTA_ASTER_FLOWER_POT, null);
	public static final RegistryObject<Item> GOLDENROD_FLOWER_POT = block(TaleOfBiomesModBlocks.GOLDENROD_FLOWER_POT, null);
	public static final RegistryObject<Item> WILD_INDIGO_FLOWER_POT = block(TaleOfBiomesModBlocks.WILD_INDIGO_FLOWER_POT, null);
	public static final RegistryObject<Item> FERTILE_SOIL = block(TaleOfBiomesModBlocks.FERTILE_SOIL, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> TILLED_SOIL = block(TaleOfBiomesModBlocks.TILLED_SOIL, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> TALL_GRASS_0 = block(TaleOfBiomesModBlocks.TALL_GRASS_0, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> TALL_GRASS_1 = block(TaleOfBiomesModBlocks.TALL_GRASS_1, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> TALL_GRASS_2 = block(TaleOfBiomesModBlocks.TALL_GRASS_2, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> IVY_SHRUB = block(TaleOfBiomesModBlocks.IVY_SHRUB, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> ROSE_SHRUB = block(TaleOfBiomesModBlocks.ROSE_SHRUB, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PURE_COAL_ORE = block(TaleOfBiomesModBlocks.PURE_COAL_ORE, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> GRAVEL = block(TaleOfBiomesModBlocks.GRAVEL, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PHOSPHORITE_STONE = block(TaleOfBiomesModBlocks.PHOSPHORITE_STONE, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PHOSPHORITE_CRYSTAL = block(TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PHOSPHORITE_CRYSTAL_BOTTOM = block(TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_BOTTOM, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PHOSPHORITE_CRYSTAL_TOP = block(TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_TOP, TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB);
	public static final RegistryObject<Item> PHOSPHORITE_GEMSTONE = REGISTRY.register("phosphorite_gemstone", () -> new PhosphoriteGemstoneItem());
	public static final RegistryObject<Item> PHOSPHORITE_PICKAXE = REGISTRY.register("phosphorite_pickaxe", () -> new PhosphoritePickaxeItem());
	public static final RegistryObject<Item> PHOSPHORITE_AXE = REGISTRY.register("phosphorite_axe", () -> new PhosphoriteAxeItem());
	public static final RegistryObject<Item> PHOSPHORITE_SHOVEL = REGISTRY.register("phosphorite_shovel", () -> new PhosphoriteShovelItem());
	public static final RegistryObject<Item> PHOSPHORITE_HOE = REGISTRY.register("phosphorite_hoe", () -> new PhosphoriteHoeItem());
	public static final RegistryObject<Item> PHOSPHORITE_SWORD = REGISTRY.register("phosphorite_sword", () -> new PhosphoriteSwordItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
