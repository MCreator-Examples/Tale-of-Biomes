
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.biome.Biome;

import net.mcreator.taleofbiomes.world.biome.GrassShrubPlainsBiome;
import net.mcreator.taleofbiomes.world.biome.GrassPlainsBiome;
import net.mcreator.taleofbiomes.world.biome.FlowerShrubPlainsBiome;
import net.mcreator.taleofbiomes.world.biome.FlowerPlainsBiome;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModBiomes {
	public static final DeferredRegister<Biome> REGISTRY = DeferredRegister.create(ForgeRegistries.BIOMES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Biome> GRASS_PLAINS = REGISTRY.register("grass_plains", GrassPlainsBiome::createBiome);
	public static final RegistryObject<Biome> FLOWER_PLAINS = REGISTRY.register("flower_plains", FlowerPlainsBiome::createBiome);
	public static final RegistryObject<Biome> GRASS_SHRUB_PLAINS = REGISTRY.register("grass_shrub_plains", GrassShrubPlainsBiome::createBiome);
	public static final RegistryObject<Biome> FLOWER_SHRUB_PLAINS = REGISTRY.register("flower_shrub_plains", FlowerShrubPlainsBiome::createBiome);
}
