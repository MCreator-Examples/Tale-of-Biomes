
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.taleofbiomes.block.entity.PhosphoriteStoneBlockEntity;
import net.mcreator.taleofbiomes.block.entity.PhosphoriteCrystalBlockEntity;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> PHOSPHORITE_STONE = register("phosphorite_stone", TaleOfBiomesModBlocks.PHOSPHORITE_STONE, PhosphoriteStoneBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> PHOSPHORITE_CRYSTAL = register("phosphorite_crystal", TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL, PhosphoriteCrystalBlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
