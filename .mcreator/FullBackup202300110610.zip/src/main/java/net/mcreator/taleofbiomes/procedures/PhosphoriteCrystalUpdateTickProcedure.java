package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.taleofbiomes.init.TaleOfBiomesModBlocks;

public class PhosphoriteCrystalUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getFluidState(new BlockPos(x, y + 1, z)).createLegacyBlock()).getBlock() == Blocks.WATER && !((world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_TOP.get())) {
			world.setBlock(new BlockPos(x, y, z),
					(TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_BOTTOM.get().getStateDefinition().getProperty("waterlogged") instanceof BooleanProperty _withbp4
							? TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_BOTTOM.get().defaultBlockState().setValue(_withbp4, (true))
							: TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_BOTTOM.get().defaultBlockState()),
					3);
			world.setBlock(new BlockPos(x, y + 1, z),
					(TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_TOP.get().getStateDefinition().getProperty("waterlogged") instanceof BooleanProperty _withbp6
							? TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_TOP.get().defaultBlockState().setValue(_withbp6, (true))
							: TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL_TOP.get().defaultBlockState()),
					3);
		}
	}
}
