
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class TaleOfBiomesModTabs {
	public static CreativeModeTab TAB_TALES_OF_BIOMES_TAB;

	public static void load() {
		TAB_TALES_OF_BIOMES_TAB = new CreativeModeTab("tabtales_of_biomes_tab") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(TaleOfBiomesModBlocks.GOLDENROD.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
