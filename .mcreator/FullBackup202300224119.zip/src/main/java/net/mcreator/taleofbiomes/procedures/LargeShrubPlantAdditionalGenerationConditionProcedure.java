package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.LevelAccessor;

public class LargeShrubPlantAdditionalGenerationConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (LargeShrubPlacementScriptProcedure.execute(world, x, y, z) == true) {
			return true;
		}
		return false;
	}
}
