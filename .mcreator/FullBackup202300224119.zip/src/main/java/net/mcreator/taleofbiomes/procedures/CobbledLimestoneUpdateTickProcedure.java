package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.taleofbiomes.init.TaleOfBiomesModBlocks;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

import java.util.Map;

public class CobbledLimestoneUpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if ((world.getBlockState(new BlockPos(x, y - 1, z))).is(BlockTags.create(new ResourceLocation("tale_of_biomes:quicklime/fuel")))
				&& (world.getBlockState(new BlockPos(x, y + 1, z))).is(BlockTags.create(new ResourceLocation("tale_of_biomes:quicklime/fuel")))
				&& (world.getBlockState(new BlockPos(x, y + 3, z))).is(BlockTags.create(new ResourceLocation("tale_of_biomes:quicklime/fuel"))) && (world.getBlockState(new BlockPos(x, y + 2, z))).getBlock() == blockstate.getBlock()
				&& (world.getBlockState(new BlockPos(x, y + 4, z))).getBlock() == blockstate.getBlock() && (world.getBlockState(new BlockPos(x, y - 2, z)))
						.getBlock() == (Blocks.CAMPFIRE.getStateDefinition().getProperty("lit") instanceof BooleanProperty _withbp13 ? Blocks.CAMPFIRE.defaultBlockState().setValue(_withbp13, true) : Blocks.CAMPFIRE.defaultBlockState()).getBlock()) {
			TaleOfBiomesMod.queueServerWork(1200, () -> {
				world.setBlock(new BlockPos(x, y - 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(new BlockPos(x, y + 3, z), Blocks.AIR.defaultBlockState(), 3);
				{
					BlockPos _bp = new BlockPos(x, y, z);
					BlockState _bs = TaleOfBiomesModBlocks.QUICKLIME_BLOCK.get().defaultBlockState();
					BlockState _bso = world.getBlockState(_bp);
					for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
						Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
						if (_property != null && _bs.getValue(_property) != null)
							try {
								_bs = _bs.setValue(_property, (Comparable) entry.getValue());
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp, _bs, 3);
				}
				{
					BlockPos _bp = new BlockPos(x, y + 2, z);
					BlockState _bs = TaleOfBiomesModBlocks.QUICKLIME_BLOCK.get().defaultBlockState();
					BlockState _bso = world.getBlockState(_bp);
					for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
						Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
						if (_property != null && _bs.getValue(_property) != null)
							try {
								_bs = _bs.setValue(_property, (Comparable) entry.getValue());
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp, _bs, 3);
				}
				{
					BlockPos _bp = new BlockPos(x, y + 4, z);
					BlockState _bs = TaleOfBiomesModBlocks.QUICKLIME_BLOCK.get().defaultBlockState();
					BlockState _bso = world.getBlockState(_bp);
					for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
						Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
						if (_property != null && _bs.getValue(_property) != null)
							try {
								_bs = _bs.setValue(_property, (Comparable) entry.getValue());
							} catch (Exception e) {
							}
					}
					world.setBlock(_bp, _bs, 3);
				}
			});
		}
	}
}
