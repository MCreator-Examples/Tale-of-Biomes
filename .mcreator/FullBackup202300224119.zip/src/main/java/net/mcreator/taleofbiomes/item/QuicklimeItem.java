
package net.mcreator.taleofbiomes.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.mcreator.taleofbiomes.init.TaleOfBiomesModTabs;

public class QuicklimeItem extends Item {
	public QuicklimeItem() {
		super(new Item.Properties().tab(TaleOfBiomesModTabs.TAB_TALES_OF_BIOMES_TAB).stacksTo(64).rarity(Rarity.COMMON));
	}
}
