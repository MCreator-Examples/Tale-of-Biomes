package net.mcreator.taleofbiomes.procedures;

public class TilledSoilBlockAddedProcedure {
	public static void execute() {
	}
}
