
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.taleofbiomes.world.features.plants.WildIndigoFeature;
import net.mcreator.taleofbiomes.world.features.plants.PurpleAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.MagentaAsterFeature;
import net.mcreator.taleofbiomes.world.features.plants.GoldenrodFeature;
import net.mcreator.taleofbiomes.world.features.plants.BlueAsterFeature;
import net.mcreator.taleofbiomes.world.features.ores.SandFeature;
import net.mcreator.taleofbiomes.world.features.ores.PureCoalOreFeature;
import net.mcreator.taleofbiomes.world.features.ores.LimestoneFeature;
import net.mcreator.taleofbiomes.world.features.ores.GravelFeature;
import net.mcreator.taleofbiomes.world.features.ores.FertileSoilFeature;
import net.mcreator.taleofbiomes.world.features.ores.DirtFeature;
import net.mcreator.taleofbiomes.world.features.ores.ClayBlockFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeWestWoodsFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeWestForestFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeWestFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeSouthWoodsFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeSouthForestFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeSouthFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeNorthWoodsFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeNorthForestFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeNorthFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeEastWoodsFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeEastForestFeature;
import net.mcreator.taleofbiomes.world.features.SmallPiruffTreeEastFeature;
import net.mcreator.taleofbiomes.world.features.RoseShrubPlant2Feature;
import net.mcreator.taleofbiomes.world.features.RoseShrubPlant1Feature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeWestWoodsFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeWestFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeSouthWoodsFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeSouthFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeNorthWoodsFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeNorthFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeEastWoodsFeature;
import net.mcreator.taleofbiomes.world.features.PiruffTreeEastFeature;
import net.mcreator.taleofbiomes.world.features.PhosphoriteCrystalSmallFeature;
import net.mcreator.taleofbiomes.world.features.PhosphoriteCrystalLaregeFeature;
import net.mcreator.taleofbiomes.world.features.IvyShrubPlant2Feature;
import net.mcreator.taleofbiomes.world.features.IvyShrubPlant1Feature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationTwoForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationTwoForForestsBoimesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationThreeForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationThreeForForestsBoimesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationOneForPlainsBiomesFeature;
import net.mcreator.taleofbiomes.world.features.GrassGenerationOneForForestsBoimesFeature;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

@Mod.EventBusSubscriber
public class TaleOfBiomesModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Feature<?>> SAND = REGISTRY.register("sand", SandFeature::feature);
	public static final RegistryObject<Feature<?>> DIRT = REGISTRY.register("dirt", DirtFeature::feature);
	public static final RegistryObject<Feature<?>> BLUE_ASTER = REGISTRY.register("blue_aster", BlueAsterFeature::feature);
	public static final RegistryObject<Feature<?>> PURPLE_ASTER = REGISTRY.register("purple_aster", PurpleAsterFeature::feature);
	public static final RegistryObject<Feature<?>> MAGENTA_ASTER = REGISTRY.register("magenta_aster", MagentaAsterFeature::feature);
	public static final RegistryObject<Feature<?>> GOLDENROD = REGISTRY.register("goldenrod", GoldenrodFeature::feature);
	public static final RegistryObject<Feature<?>> WILD_INDIGO = REGISTRY.register("wild_indigo", WildIndigoFeature::feature);
	public static final RegistryObject<Feature<?>> FERTILE_SOIL = REGISTRY.register("fertile_soil", FertileSoilFeature::feature);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_ONE_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_one_for_plains_biomes", GrassGenerationOneForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_TWO_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_two_for_plains_biomes", GrassGenerationTwoForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_THREE_FOR_PLAINS_BIOMES = REGISTRY.register("grass_generation_three_for_plains_biomes", GrassGenerationThreeForPlainsBiomesFeature::new);
	public static final RegistryObject<Feature<?>> IVY_SHRUB_PLANT_1 = REGISTRY.register("ivy_shrub_plant_1", IvyShrubPlant1Feature::feature);
	public static final RegistryObject<Feature<?>> IVY_SHRUB_PLANT_2 = REGISTRY.register("ivy_shrub_plant_2", IvyShrubPlant2Feature::feature);
	public static final RegistryObject<Feature<?>> ROSE_SHRUB_PLANT_1 = REGISTRY.register("rose_shrub_plant_1", RoseShrubPlant1Feature::feature);
	public static final RegistryObject<Feature<?>> ROSE_SHRUB_PLANT_2 = REGISTRY.register("rose_shrub_plant_2", RoseShrubPlant2Feature::feature);
	public static final RegistryObject<Feature<?>> PURE_COAL_ORE = REGISTRY.register("pure_coal_ore", PureCoalOreFeature::feature);
	public static final RegistryObject<Feature<?>> GRAVEL = REGISTRY.register("gravel", GravelFeature::feature);
	public static final RegistryObject<Feature<?>> PHOSPHORITE_CRYSTAL_LAREGE = REGISTRY.register("phosphorite_crystal_larege", PhosphoriteCrystalLaregeFeature::feature);
	public static final RegistryObject<Feature<?>> PHOSPHORITE_CRYSTAL_SMALL = REGISTRY.register("phosphorite_crystal_small", PhosphoriteCrystalSmallFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_EAST = REGISTRY.register("piruff_tree_east", PiruffTreeEastFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_NORTH = REGISTRY.register("piruff_tree_north", PiruffTreeNorthFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_SOUTH = REGISTRY.register("piruff_tree_south", PiruffTreeSouthFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_WEST = REGISTRY.register("piruff_tree_west", PiruffTreeWestFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_EAST = REGISTRY.register("small_piruff_tree_east", SmallPiruffTreeEastFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_NORTH = REGISTRY.register("small_piruff_tree_north", SmallPiruffTreeNorthFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_SOUTH = REGISTRY.register("small_piruff_tree_south", SmallPiruffTreeSouthFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_WEST = REGISTRY.register("small_piruff_tree_west", SmallPiruffTreeWestFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_WEST_WOODS = REGISTRY.register("piruff_tree_west_woods", PiruffTreeWestWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_SOUTH_WOODS = REGISTRY.register("piruff_tree_south_woods", PiruffTreeSouthWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_NORTH_WOODS = REGISTRY.register("piruff_tree_north_woods", PiruffTreeNorthWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> PIRUFF_TREE_EAST_WOODS = REGISTRY.register("piruff_tree_east_woods", PiruffTreeEastWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_ONE_FOR_FORESTS_BOIMES = REGISTRY.register("grass_generation_one_for_forests_boimes", GrassGenerationOneForForestsBoimesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_TWO_FOR_FORESTS_BOIMES = REGISTRY.register("grass_generation_two_for_forests_boimes", GrassGenerationTwoForForestsBoimesFeature::new);
	public static final RegistryObject<Feature<?>> GRASS_GENERATION_THREE_FOR_FORESTS_BOIMES = REGISTRY.register("grass_generation_three_for_forests_boimes", GrassGenerationThreeForForestsBoimesFeature::new);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_EAST_WOODS = REGISTRY.register("small_piruff_tree_east_woods", SmallPiruffTreeEastWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_NORTH_WOODS = REGISTRY.register("small_piruff_tree_north_woods", SmallPiruffTreeNorthWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_SOUTH_WOODS = REGISTRY.register("small_piruff_tree_south_woods", SmallPiruffTreeSouthWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_WEST_WOODS = REGISTRY.register("small_piruff_tree_west_woods", SmallPiruffTreeWestWoodsFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_EAST_FOREST = REGISTRY.register("small_piruff_tree_east_forest", SmallPiruffTreeEastForestFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_NORTH_FOREST = REGISTRY.register("small_piruff_tree_north_forest", SmallPiruffTreeNorthForestFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_SOUTH_FOREST = REGISTRY.register("small_piruff_tree_south_forest", SmallPiruffTreeSouthForestFeature::feature);
	public static final RegistryObject<Feature<?>> SMALL_PIRUFF_TREE_WEST_FOREST = REGISTRY.register("small_piruff_tree_west_forest", SmallPiruffTreeWestForestFeature::feature);
	public static final RegistryObject<Feature<?>> CLAY_BLOCK = REGISTRY.register("clay_block", ClayBlockFeature::feature);
	public static final RegistryObject<Feature<?>> LIMESTONE = REGISTRY.register("limestone", LimestoneFeature::feature);
}
