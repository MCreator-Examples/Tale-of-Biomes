
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.taleofbiomes.block.WildIndigoFlowerPotBlock;
import net.mcreator.taleofbiomes.block.WildIndigoBlock;
import net.mcreator.taleofbiomes.block.TilledSoilW4S4Block;
import net.mcreator.taleofbiomes.block.TilledSoilW4S3Block;
import net.mcreator.taleofbiomes.block.TilledSoilW4S2Block;
import net.mcreator.taleofbiomes.block.TilledSoilW4S1Block;
import net.mcreator.taleofbiomes.block.TilledSoilW4S0Block;
import net.mcreator.taleofbiomes.block.TilledSoilW3S4Block;
import net.mcreator.taleofbiomes.block.TilledSoilW3S3Block;
import net.mcreator.taleofbiomes.block.TilledSoilW3S2Block;
import net.mcreator.taleofbiomes.block.TilledSoilW3S1Block;
import net.mcreator.taleofbiomes.block.TilledSoilW3S0Block;
import net.mcreator.taleofbiomes.block.TilledSoilW2S4Block;
import net.mcreator.taleofbiomes.block.TilledSoilW2S3Block;
import net.mcreator.taleofbiomes.block.TilledSoilW2S2Block;
import net.mcreator.taleofbiomes.block.TilledSoilW2S1Block;
import net.mcreator.taleofbiomes.block.TilledSoilW2S0Block;
import net.mcreator.taleofbiomes.block.TilledSoilW1S4Block;
import net.mcreator.taleofbiomes.block.TilledSoilW1S3Block;
import net.mcreator.taleofbiomes.block.TilledSoilW1S2Block;
import net.mcreator.taleofbiomes.block.TilledSoilW1S1Block;
import net.mcreator.taleofbiomes.block.TilledSoilW1S0Block;
import net.mcreator.taleofbiomes.block.TilledSoilW0S4Block;
import net.mcreator.taleofbiomes.block.TilledSoilW0S3Block;
import net.mcreator.taleofbiomes.block.TilledSoilW0S2Block;
import net.mcreator.taleofbiomes.block.TilledSoilW0S1Block;
import net.mcreator.taleofbiomes.block.TilledSoilBlock;
import net.mcreator.taleofbiomes.block.TallGrass2Block;
import net.mcreator.taleofbiomes.block.TallGrass1Block;
import net.mcreator.taleofbiomes.block.TallGrass0Block;
import net.mcreator.taleofbiomes.block.StoneBlock;
import net.mcreator.taleofbiomes.block.SandBlock;
import net.mcreator.taleofbiomes.block.RoseShrubBlock;
import net.mcreator.taleofbiomes.block.QuicklimeBlockBlock;
import net.mcreator.taleofbiomes.block.PurpleAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.PurpleAsterBlock;
import net.mcreator.taleofbiomes.block.PureCoalOreBlock;
import net.mcreator.taleofbiomes.block.PiruffWoodBlock;
import net.mcreator.taleofbiomes.block.PiruffLogBlock;
import net.mcreator.taleofbiomes.block.PiruffLeavesBlock;
import net.mcreator.taleofbiomes.block.PhosphoriteStoneBlock;
import net.mcreator.taleofbiomes.block.PhosphoriteCrystalTopBlock;
import net.mcreator.taleofbiomes.block.PhosphoriteCrystalBottomBlock;
import net.mcreator.taleofbiomes.block.PhosphoriteCrystalBlock;
import net.mcreator.taleofbiomes.block.MagentaAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.MagentaAsterBlock;
import net.mcreator.taleofbiomes.block.LimestoneBlock;
import net.mcreator.taleofbiomes.block.LargeBricksBlock;
import net.mcreator.taleofbiomes.block.LargeBrickWallBlock;
import net.mcreator.taleofbiomes.block.LargeBrickSlabsBlock;
import net.mcreator.taleofbiomes.block.LargeBrickPressurePlateBlock;
import net.mcreator.taleofbiomes.block.LargeBrickButtonBlock;
import net.mcreator.taleofbiomes.block.LargeBirckStairsBlock;
import net.mcreator.taleofbiomes.block.IvyShrubBlock;
import net.mcreator.taleofbiomes.block.GravelBlock;
import net.mcreator.taleofbiomes.block.GrassBlockBlock;
import net.mcreator.taleofbiomes.block.GoldenrodFlowerPotBlock;
import net.mcreator.taleofbiomes.block.GoldenrodBlock;
import net.mcreator.taleofbiomes.block.FertileSoilBlock;
import net.mcreator.taleofbiomes.block.DirtBlock;
import net.mcreator.taleofbiomes.block.CobbledLimestoneBlock;
import net.mcreator.taleofbiomes.block.ClayBlockBlock;
import net.mcreator.taleofbiomes.block.BricksBlock;
import net.mcreator.taleofbiomes.block.BrickWallBlock;
import net.mcreator.taleofbiomes.block.BrickStairsBlock;
import net.mcreator.taleofbiomes.block.BrickSlabBlock;
import net.mcreator.taleofbiomes.block.BrickPressurePlateBlock;
import net.mcreator.taleofbiomes.block.BrickButtonBlock;
import net.mcreator.taleofbiomes.block.BlueAsterFlowerPotBlock;
import net.mcreator.taleofbiomes.block.BlueAsterBlock;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TaleOfBiomesMod.MODID);
	public static final RegistryObject<Block> STONE = REGISTRY.register("stone", () -> new StoneBlock());
	public static final RegistryObject<Block> SAND = REGISTRY.register("sand", () -> new SandBlock());
	public static final RegistryObject<Block> GRASS_BLOCK = REGISTRY.register("grass_block", () -> new GrassBlockBlock());
	public static final RegistryObject<Block> DIRT = REGISTRY.register("dirt", () -> new DirtBlock());
	public static final RegistryObject<Block> BLUE_ASTER = REGISTRY.register("blue_aster", () -> new BlueAsterBlock());
	public static final RegistryObject<Block> PURPLE_ASTER = REGISTRY.register("purple_aster", () -> new PurpleAsterBlock());
	public static final RegistryObject<Block> MAGENTA_ASTER = REGISTRY.register("magenta_aster", () -> new MagentaAsterBlock());
	public static final RegistryObject<Block> GOLDENROD = REGISTRY.register("goldenrod", () -> new GoldenrodBlock());
	public static final RegistryObject<Block> WILD_INDIGO = REGISTRY.register("wild_indigo", () -> new WildIndigoBlock());
	public static final RegistryObject<Block> BLUE_ASTER_FLOWER_POT = REGISTRY.register("blue_aster_flower_pot", () -> new BlueAsterFlowerPotBlock());
	public static final RegistryObject<Block> PURPLE_ASTER_FLOWER_POT = REGISTRY.register("purple_aster_flower_pot", () -> new PurpleAsterFlowerPotBlock());
	public static final RegistryObject<Block> MAGENTA_ASTER_FLOWER_POT = REGISTRY.register("magenta_aster_flower_pot", () -> new MagentaAsterFlowerPotBlock());
	public static final RegistryObject<Block> GOLDENROD_FLOWER_POT = REGISTRY.register("goldenrod_flower_pot", () -> new GoldenrodFlowerPotBlock());
	public static final RegistryObject<Block> WILD_INDIGO_FLOWER_POT = REGISTRY.register("wild_indigo_flower_pot", () -> new WildIndigoFlowerPotBlock());
	public static final RegistryObject<Block> FERTILE_SOIL = REGISTRY.register("fertile_soil", () -> new FertileSoilBlock());
	public static final RegistryObject<Block> TILLED_SOIL = REGISTRY.register("tilled_soil", () -> new TilledSoilBlock());
	public static final RegistryObject<Block> TALL_GRASS_0 = REGISTRY.register("tall_grass_0", () -> new TallGrass0Block());
	public static final RegistryObject<Block> TALL_GRASS_1 = REGISTRY.register("tall_grass_1", () -> new TallGrass1Block());
	public static final RegistryObject<Block> TALL_GRASS_2 = REGISTRY.register("tall_grass_2", () -> new TallGrass2Block());
	public static final RegistryObject<Block> IVY_SHRUB = REGISTRY.register("ivy_shrub", () -> new IvyShrubBlock());
	public static final RegistryObject<Block> ROSE_SHRUB = REGISTRY.register("rose_shrub", () -> new RoseShrubBlock());
	public static final RegistryObject<Block> PURE_COAL_ORE = REGISTRY.register("pure_coal_ore", () -> new PureCoalOreBlock());
	public static final RegistryObject<Block> GRAVEL = REGISTRY.register("gravel", () -> new GravelBlock());
	public static final RegistryObject<Block> PHOSPHORITE_STONE = REGISTRY.register("phosphorite_stone", () -> new PhosphoriteStoneBlock());
	public static final RegistryObject<Block> PHOSPHORITE_CRYSTAL = REGISTRY.register("phosphorite_crystal", () -> new PhosphoriteCrystalBlock());
	public static final RegistryObject<Block> PHOSPHORITE_CRYSTAL_BOTTOM = REGISTRY.register("phosphorite_crystal_bottom", () -> new PhosphoriteCrystalBottomBlock());
	public static final RegistryObject<Block> PHOSPHORITE_CRYSTAL_TOP = REGISTRY.register("phosphorite_crystal_top", () -> new PhosphoriteCrystalTopBlock());
	public static final RegistryObject<Block> PIRUFF_LOG = REGISTRY.register("piruff_log", () -> new PiruffLogBlock());
	public static final RegistryObject<Block> PIRUFF_LEAVES = REGISTRY.register("piruff_leaves", () -> new PiruffLeavesBlock());
	public static final RegistryObject<Block> PIRUFF_WOOD = REGISTRY.register("piruff_wood", () -> new PiruffWoodBlock());
	public static final RegistryObject<Block> TILLED_SOIL_W_1_S_0 = REGISTRY.register("tilled_soil_w_1_s_0", () -> new TilledSoilW1S0Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_1_S_1 = REGISTRY.register("tilled_soil_w_1_s_1", () -> new TilledSoilW1S1Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_1_S_2 = REGISTRY.register("tilled_soil_w_1_s_2", () -> new TilledSoilW1S2Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_1_S_3 = REGISTRY.register("tilled_soil_w_1_s_3", () -> new TilledSoilW1S3Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_1_S_4 = REGISTRY.register("tilled_soil_w_1_s_4", () -> new TilledSoilW1S4Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_2_S_0 = REGISTRY.register("tilled_soil_w_2_s_0", () -> new TilledSoilW2S0Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_2_S_1 = REGISTRY.register("tilled_soil_w_2_s_1", () -> new TilledSoilW2S1Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_2_S_2 = REGISTRY.register("tilled_soil_w_2_s_2", () -> new TilledSoilW2S2Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_2_S_3 = REGISTRY.register("tilled_soil_w_2_s_3", () -> new TilledSoilW2S3Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_2_S_4 = REGISTRY.register("tilled_soil_w_2_s_4", () -> new TilledSoilW2S4Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_3_S_0 = REGISTRY.register("tilled_soil_w_3_s_0", () -> new TilledSoilW3S0Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_3_S_1 = REGISTRY.register("tilled_soil_w_3_s_1", () -> new TilledSoilW3S1Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_3_S_2 = REGISTRY.register("tilled_soil_w_3_s_2", () -> new TilledSoilW3S2Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_3_S_3 = REGISTRY.register("tilled_soil_w_3_s_3", () -> new TilledSoilW3S3Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_3_S_4 = REGISTRY.register("tilled_soil_w_3_s_4", () -> new TilledSoilW3S4Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_4_S_0 = REGISTRY.register("tilled_soil_w_4_s_0", () -> new TilledSoilW4S0Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_4_S_1 = REGISTRY.register("tilled_soil_w_4_s_1", () -> new TilledSoilW4S1Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_4_S_2 = REGISTRY.register("tilled_soil_w_4_s_2", () -> new TilledSoilW4S2Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_4_S_3 = REGISTRY.register("tilled_soil_w_4_s_3", () -> new TilledSoilW4S3Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_4_S_4 = REGISTRY.register("tilled_soil_w_4_s_4", () -> new TilledSoilW4S4Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_0_S_1 = REGISTRY.register("tilled_soil_w_0_s_1", () -> new TilledSoilW0S1Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_0_S_2 = REGISTRY.register("tilled_soil_w_0_s_2", () -> new TilledSoilW0S2Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_0_S_3 = REGISTRY.register("tilled_soil_w_0_s_3", () -> new TilledSoilW0S3Block());
	public static final RegistryObject<Block> TILLED_SOIL_W_0_S_4 = REGISTRY.register("tilled_soil_w_0_s_4", () -> new TilledSoilW0S4Block());
	public static final RegistryObject<Block> CLAY_BLOCK = REGISTRY.register("clay_block", () -> new ClayBlockBlock());
	public static final RegistryObject<Block> BRICKS = REGISTRY.register("bricks", () -> new BricksBlock());
	public static final RegistryObject<Block> LARGE_BRICKS = REGISTRY.register("large_bricks", () -> new LargeBricksBlock());
	public static final RegistryObject<Block> LARGE_BIRCK_STAIRS = REGISTRY.register("large_birck_stairs", () -> new LargeBirckStairsBlock());
	public static final RegistryObject<Block> LARGE_BRICK_SLABS = REGISTRY.register("large_brick_slabs", () -> new LargeBrickSlabsBlock());
	public static final RegistryObject<Block> LARGE_BRICK_WALL = REGISTRY.register("large_brick_wall", () -> new LargeBrickWallBlock());
	public static final RegistryObject<Block> LARGE_BRICK_PRESSURE_PLATE = REGISTRY.register("large_brick_pressure_plate", () -> new LargeBrickPressurePlateBlock());
	public static final RegistryObject<Block> LARGE_BRICK_BUTTON = REGISTRY.register("large_brick_button", () -> new LargeBrickButtonBlock());
	public static final RegistryObject<Block> BRICK_STAIRS = REGISTRY.register("brick_stairs", () -> new BrickStairsBlock());
	public static final RegistryObject<Block> BRICK_SLAB = REGISTRY.register("brick_slab", () -> new BrickSlabBlock());
	public static final RegistryObject<Block> BRICK_WALL = REGISTRY.register("brick_wall", () -> new BrickWallBlock());
	public static final RegistryObject<Block> BRICK_PRESSURE_PLATE = REGISTRY.register("brick_pressure_plate", () -> new BrickPressurePlateBlock());
	public static final RegistryObject<Block> BRICK_BUTTON = REGISTRY.register("brick_button", () -> new BrickButtonBlock());
	public static final RegistryObject<Block> LIMESTONE = REGISTRY.register("limestone", () -> new LimestoneBlock());
	public static final RegistryObject<Block> COBBLED_LIMESTONE = REGISTRY.register("cobbled_limestone", () -> new CobbledLimestoneBlock());
	public static final RegistryObject<Block> QUICKLIME_BLOCK = REGISTRY.register("quicklime_block", () -> new QuicklimeBlockBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			GrassBlockBlock.blockColorLoad(event);
			TallGrass0Block.blockColorLoad(event);
			TallGrass1Block.blockColorLoad(event);
			TallGrass2Block.blockColorLoad(event);
			PiruffLeavesBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			GrassBlockBlock.itemColorLoad(event);
			TallGrass0Block.itemColorLoad(event);
			TallGrass1Block.itemColorLoad(event);
			TallGrass2Block.itemColorLoad(event);
			PiruffLeavesBlock.itemColorLoad(event);
		}
	}
}
