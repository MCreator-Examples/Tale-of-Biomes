
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.taleofbiomes.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.taleofbiomes.block.entity.TilledSoilW4S4BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW4S3BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW4S2BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW4S1BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW4S0BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW3S4BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW3S3BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW3S2BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW3S1BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW3S0BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW2S4BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW2S3BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW2S2BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW2S1BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW2S0BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW1S4BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW1S3BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW1S2BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW1S1BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW1S0BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW0S4BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW0S3BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW0S2BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilW0S1BlockEntity;
import net.mcreator.taleofbiomes.block.entity.TilledSoilBlockEntity;
import net.mcreator.taleofbiomes.block.entity.PhosphoriteStoneBlockEntity;
import net.mcreator.taleofbiomes.block.entity.PhosphoriteCrystalBlockEntity;
import net.mcreator.taleofbiomes.TaleOfBiomesMod;

public class TaleOfBiomesModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TaleOfBiomesMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL = register("tilled_soil", TaleOfBiomesModBlocks.TILLED_SOIL, TilledSoilBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> PHOSPHORITE_STONE = register("phosphorite_stone", TaleOfBiomesModBlocks.PHOSPHORITE_STONE, PhosphoriteStoneBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> PHOSPHORITE_CRYSTAL = register("phosphorite_crystal", TaleOfBiomesModBlocks.PHOSPHORITE_CRYSTAL, PhosphoriteCrystalBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_1_S_0 = register("tilled_soil_w_1_s_0", TaleOfBiomesModBlocks.TILLED_SOIL_W_1_S_0, TilledSoilW1S0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_1_S_1 = register("tilled_soil_w_1_s_1", TaleOfBiomesModBlocks.TILLED_SOIL_W_1_S_1, TilledSoilW1S1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_1_S_2 = register("tilled_soil_w_1_s_2", TaleOfBiomesModBlocks.TILLED_SOIL_W_1_S_2, TilledSoilW1S2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_1_S_3 = register("tilled_soil_w_1_s_3", TaleOfBiomesModBlocks.TILLED_SOIL_W_1_S_3, TilledSoilW1S3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_1_S_4 = register("tilled_soil_w_1_s_4", TaleOfBiomesModBlocks.TILLED_SOIL_W_1_S_4, TilledSoilW1S4BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_2_S_0 = register("tilled_soil_w_2_s_0", TaleOfBiomesModBlocks.TILLED_SOIL_W_2_S_0, TilledSoilW2S0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_2_S_1 = register("tilled_soil_w_2_s_1", TaleOfBiomesModBlocks.TILLED_SOIL_W_2_S_1, TilledSoilW2S1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_2_S_2 = register("tilled_soil_w_2_s_2", TaleOfBiomesModBlocks.TILLED_SOIL_W_2_S_2, TilledSoilW2S2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_2_S_3 = register("tilled_soil_w_2_s_3", TaleOfBiomesModBlocks.TILLED_SOIL_W_2_S_3, TilledSoilW2S3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_2_S_4 = register("tilled_soil_w_2_s_4", TaleOfBiomesModBlocks.TILLED_SOIL_W_2_S_4, TilledSoilW2S4BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_3_S_0 = register("tilled_soil_w_3_s_0", TaleOfBiomesModBlocks.TILLED_SOIL_W_3_S_0, TilledSoilW3S0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_3_S_1 = register("tilled_soil_w_3_s_1", TaleOfBiomesModBlocks.TILLED_SOIL_W_3_S_1, TilledSoilW3S1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_3_S_2 = register("tilled_soil_w_3_s_2", TaleOfBiomesModBlocks.TILLED_SOIL_W_3_S_2, TilledSoilW3S2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_3_S_3 = register("tilled_soil_w_3_s_3", TaleOfBiomesModBlocks.TILLED_SOIL_W_3_S_3, TilledSoilW3S3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_3_S_4 = register("tilled_soil_w_3_s_4", TaleOfBiomesModBlocks.TILLED_SOIL_W_3_S_4, TilledSoilW3S4BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_4_S_0 = register("tilled_soil_w_4_s_0", TaleOfBiomesModBlocks.TILLED_SOIL_W_4_S_0, TilledSoilW4S0BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_4_S_1 = register("tilled_soil_w_4_s_1", TaleOfBiomesModBlocks.TILLED_SOIL_W_4_S_1, TilledSoilW4S1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_4_S_2 = register("tilled_soil_w_4_s_2", TaleOfBiomesModBlocks.TILLED_SOIL_W_4_S_2, TilledSoilW4S2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_4_S_3 = register("tilled_soil_w_4_s_3", TaleOfBiomesModBlocks.TILLED_SOIL_W_4_S_3, TilledSoilW4S3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_4_S_4 = register("tilled_soil_w_4_s_4", TaleOfBiomesModBlocks.TILLED_SOIL_W_4_S_4, TilledSoilW4S4BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_0_S_1 = register("tilled_soil_w_0_s_1", TaleOfBiomesModBlocks.TILLED_SOIL_W_0_S_1, TilledSoilW0S1BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_0_S_2 = register("tilled_soil_w_0_s_2", TaleOfBiomesModBlocks.TILLED_SOIL_W_0_S_2, TilledSoilW0S2BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_0_S_3 = register("tilled_soil_w_0_s_3", TaleOfBiomesModBlocks.TILLED_SOIL_W_0_S_3, TilledSoilW0S3BlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> TILLED_SOIL_W_0_S_4 = register("tilled_soil_w_0_s_4", TaleOfBiomesModBlocks.TILLED_SOIL_W_0_S_4, TilledSoilW0S4BlockEntity::new);

	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
