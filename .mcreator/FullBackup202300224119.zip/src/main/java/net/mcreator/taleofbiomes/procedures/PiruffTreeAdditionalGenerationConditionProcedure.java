package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.LevelAccessor;

public class PiruffTreeAdditionalGenerationConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (PiruffTreeStructureScriptProcedure.execute(world, x, y, z)) {
			return true;
		}
		return false;
	}
}
