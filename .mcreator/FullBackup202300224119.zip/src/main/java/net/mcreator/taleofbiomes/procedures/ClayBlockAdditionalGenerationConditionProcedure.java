package net.mcreator.taleofbiomes.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.taleofbiomes.init.TaleOfBiomesModBlocks;

public class ClayBlockAdditionalGenerationConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if (!((world.getBlockState(new BlockPos(x, y, z))).getBlock() == TaleOfBiomesModBlocks.GRASS_BLOCK.get())) {
			return true;
		}
		return false;
	}
}
